jQuery(document).ready(function ($) 
{
	puls_plus()
});
function puls_plus(){
	$(".plus").animate({opacity:0.5}, 500);
	$(".plus").animate({opacity:1}, 500);
	setTimeout("puls_plus()",1000);
}


