jQuery(document).ready(function ($) 
	{
		$(window).scroll(function(){
            var bo = $("body").scrollTop();
        if (bo > 31)
			$(".phone").addClass('opacity_1');
		else
			$(".phone").removeClass('opacity_1');
        })	
		$(".yr_numb").ForceNumericOnly();
		$(".zakaz").click(function(){if (!$(".yr_numb").val().length)
		{
			$(".yr_numb").css({"border":"2px solid red"});
			setTimeout(function(){$(".yr_numb").css({"border":"0px solid red"});},1000);
			
		}})
	});

 
	
	
	

		
			
	
		