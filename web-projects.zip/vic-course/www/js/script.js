jQuery(document).ready(function ($) 
	{
	

    


		
	});
$(".header_nav").on("click","a", function (event) {

        //отменяем стандартную обработку нажатия по ссылке

        event.preventDefault();


 

        //забираем идентификатор бока с атрибута href

        var id  = $(this).attr('href'),

 

        //узнаем высоту от начала страницы до блока на который ссылается якорь

            top = $(id).offset().top;

         

        //анимируем переход на расстояние - top за 200 мс

        $('body,html').animate({scrollTop: top - 65}, 200);

    });
$(".best_more-inf_a").on("click", function(){
	            
	            $('body,html').animate({scrollTop: $(".main_best").offset().top-80}, 200);
    			setTimeout(function (){
    			    var d = $(window).scrollTop();
	                d = d - 200;
    			    $(".descrip_hid").removeClass("descrip_hid").addClass("descrip_shw");
    			    $(".descrip_shw").animate({opacity:100},1000);
    		    	$(".descrip_shw").css({"top":d+"px"});
    			    $(".bx-controls-direction").css("display","none");},200);
    			
		});
		$(".descrip_close").on("click", function(){
			$(".descrip_shw").removeClass("descrip_shw").addClass("descrip_hid");
			$(".bx-controls-direction").css("display","block");
			$(".descrip_shw").animate({opacity:0},1000);
		});

	$(".nav_li > a").mouseenter(function(){$(this).animate({paddingTop:13,paddingBottom:13,paddingLeft:10,paddingRight:10}),5500})
					.mouseleave(function(){$(this).animate({paddingTop:10,paddingBottom:10,paddingLeft:10,paddingRight:10})});
	
	$(window).scroll(function(){  
	var d = $(window).scrollTop();
		// отслеживаем событие
	
	if ( $(window).scrollTop() >= 175 )
	{                   // ставим условие
		$('.header_nav').removeClass("header_nav").addClass("header_nav_fix");         // определяем действие
		$('.nav_ul').removeClass("nav_ul").addClass("nav_ul_fix");
	}
	else
	{
		$('.header_nav_fix').removeClass("header_nav_fix").addClass("header_nav");
		$('.nav_ul_fix').removeClass("nav_ul_fix").addClass("nav_ul");
	}
	
	
	
});
	
	
	

		
			
	
		