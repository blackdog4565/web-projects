jQuery(document).ready(function() {  
	
	jQuery(".openhref").fancybox(
	{
	
		'scrolling':'no',
		
		
	});
	$(".openhref").click(function(){document.onmousewheel = function (e) {e.preventDefault();};$("body").css({'overflow':'hidden',}); })
	$("#fancybox-close").click(function(){document.onmousewheel = "return false";$("body").css({'overflow-y':'scroll',}); })
	
	jQuery(".podr").fancybox(
	{
	
		'scrolling':'no',
		
		
	});
	$(".podr").click(function(){document.onmousewheel = function (e) {e.preventDefault();};$("body").css({'overflow':'hidden',}); })
	$("#fancybox-close").click(function(){document.onmousewheel = "return false";$("body").css({'overflow-y':'scroll',}); })
	
	jQuery(".gallery a").fancybox(
	{
	
		'transitionIn'	:	'elastic',
		'transitionOut'	:	'elastic',
		'speedIn'		:	600, 
		'speedOut'		:	200, 
		'overlayShow'	:	false
		
		
	});
});
