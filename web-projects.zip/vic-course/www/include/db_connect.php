<?php
$db_host = localhost;
$db_user = n91721mw_bd;
$db_pass = 85756545;
$db_database = n91721mw_bd;

$link = mysql_connect($db_host,$db_user,$db_pass);

mysql_select_db($db_database,$link) or die("Нет соединения с БД".mysql_error());
mysql_query("SET names UTF-8");
?>