<?php
	include("include/db_connect.php");
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8"> 
		<link rel="stylesheet" href="css/style.css" type="text/css"/>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
		<script src="js/script.js"></script>
		
		<!-- bxSlider Javascript file -->
		<script src="js/jquery.bxslider.min.js"></script>
		<!-- bxSlider CSS file -->
		<link href="css/jquery.bxslider.css" rel="stylesheet" /> 
		<script type="text/javascript">
		jQuery(document).ready(function($)
		{
		    $('.bxslider').bxSlider(
				{
					controls: true
				}
			);
			
		});
		</script>
	</head>
	<body class="body inner">
	
		<header class="header">
			<div class="flex-row">
				
				<div class="header_descrip">
					<p class="text">Сделаем Вашу жизнь лучше!</p>
				</div>
				<div class="header_contact">
					<div class="contact_numb flex-row flex-between">
						<img src="img/phone.png" height="20" width="20"><p class=""> +7 917 211 56 ## </p>
					</div>
					<div class="contact_adr flex-row flex-between">
						<img src="img/addr.png" height="20" width="20"><p class=""> г. Саратов ул. Зенитная ##</p>
					</div>
				</div>
			</div>
			<div class="header_nav">
				<ul class="nav_ul flex-row ">
					<li class="nav_li"><a alt="one" href="#best">Лучшие проекты</a></li>
					<li class="nav_li"><a alt="two" href="#about">О компании</a></li>
					<li class="nav_li"><a alt="3" href="">Каталог</a></li>
					<li class="nav_li"><a alt="4" href="">Консультация</a></li>
					<li class="nav_li"><a alt="5" href="">Наши контакты</a></li>
				</ul>
			</div>
		</header>
		
		<section class="main">
			<div id="best" class="main_best">
				<h3 alt="one" class="h3"> Лучшие проекты </h3>
				<div class="main_slider">
					<ul class=" bxslider slidewrapper">
						<?php
							$result = mysql_query("SELECT * FROM main_table",$link);
							
							if (mysql_num_rows($result) > 0)
							{
								$row = mysql_fetch_array($result);
								
								do
								{
									echo '
									<li class="slide">
										<div class="best_img">
										    <img src="img/'.$row["image"].'" width="500" height="500">
										</div>
										<div class="flex-row">
    										<div class="best_name">
    										    <p class="best_name_p">'.$row["name"].'</p>
    										</div>
    										<div class="best_more-inf flex-row">
										        <a class="best_more-inf_a"><p class="best_more-inf_a_p">Подробнее</p></a>
									    	</div>
    										<div class="best_price best_name">
    										    <p class="best_price_p">'.$row["price"].'руб.</p>
    										</div>
    										
    									</div>
										<div class="descrip_hid">
											<div class="descrip_close">
												<h1>X</h1>
											</div>
											<div class="descrip_in">
												<div clss="descrip_img">
													<img src="img/'.$row["image"].'" width="250" height="250">
												</div>
												<div class="descrip_txt">
													<div class="descrip_name">
														<p class="">'.$row["name"].'</p>
													</div>
													<div class="descrip_price">
														<p class="">'.$row["price"].'руб.</p>
													</div>
													<div class="descrip_info">
														<p class="">'.$row["descrip"].'</p>
													</div>
												</div>
											</div>
										</div>
									</li>
									';
								}
								while($row = mysql_fetch_array($result));
							}
						
						?>
						
					</ul>
				</div>
			</div>
			<div id="about" class="main_about">
				<h3 alt="two" class="h3"> О компании </h3>
				<div class="main_box">
					<p class="about_text">
						Строим КАРКАСНЫЕ ДОМА «ПОД КЛЮЧ» 
						в Москве и МО с гарантией 20 лет <br> <br>
						+Опыт бригад от 9 лет <br>
						+Без предоплаты <br>
						+Сертифицированные материалы <br>
						+Выполнение работ от проектирования дома до монтажа розеток <br>
					</p>
				</div>
			</div>
			<div class="catalog">
				<?php
					$result = mysql_query("SELECT * FROM main_table",$link);
					
					if (mysql_num_rows($result) > 0)
					{
						$row = mysql_fetch_array($result);
						
						do
						{
							echo '
								<p>'.$row["name"].'</p>
							';
						}
						while($row = mysql_fetch_array($result));
					}
					
				?>
			</div>
		</section>
	</body>
	<script src="js/script.js"></script>
</html>