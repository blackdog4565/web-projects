	jQuery(document).ready(function ($) 
	{
		// $(".content__nav").css({"z-index":"-120"});

	});
	function select(){
		
	}
	function unslide(){

		
			$('.photo__big > img[alt^="1"]').addClass(function(v_class)
			{
				$('.photo__big > img[alt^="1"]').removeClass("now");
				return "invise";
			});
			$('.photo__small >ul>li> img[alt^="1"]').addClass(function(v_class)
			{
				$('.photo__small >ul>li> img[alt^="1"]').removeClass("non-opacity");
				return "opacity";
			});
			
			$('.photo__big > img[alt^="1"]').attr("alt","11");
			$('.photo__small >ul>li> img[alt^="1"]').attr("alt","11");
			
			$('.photo__big > img[alt^="4"]').addClass(function(v_class)
				{
					$('.photo__big > img[alt^="4"]').removeClass("invise");
					return "now";
				}
			);
			$('.photo__small >ul>li> img[alt^="4"]').addClass(function(v_class)
			{
				$('.photo__small >ul>li> img[alt^="4"]').removeClass("opacity");
				return "non-opacity";
			});
			$('.photo__big > img[alt^="4"]').attr("alt","1");
			$('.photo__small >ul>li> img[alt^="4"]').attr("alt","1");
			$('.photo__big > img[alt^="3"]').attr("alt","4");
			$('.photo__small >ul>li> img[alt^="3"]').attr("alt","4");
			$('.photo__big > img[alt^="2"]').attr("alt","3");
			$('.photo__small >ul>li> img[alt^="2"]').attr("alt","3");
			$('.photo__big > img[alt^="11"]').attr("alt","2");
			$('.photo__small >ul>li> img[alt^="11"]').attr("alt","2");
		}
	function slide(){

		
			$('.photo__big > img[alt^="1"]').addClass(function(v_class)
			{
				$('.photo__big > img[alt^="1"]').removeClass("now");
				return "invise";
			});
			$('.photo__small >ul>li> img[alt^="1"]').addClass(function(v_class)
			{
				$('.photo__small >ul>li> img[alt^="1"]').removeClass("non-opacity");
				return "opacity";
			});
			
			$('.photo__big > img[alt^="1"]').attr("alt","10");
			$('.photo__small >ul>li> img[alt^="1"]').attr("alt","10");
			
			$('.photo__big > img[alt^="2"]').addClass(function(v_class)
				{
					$('.photo__big > img[alt^="2"]').removeClass("invise");
					return "now";
				}
			);
			$('.photo__small >ul>li> img[alt^="2"]').addClass(function(v_class)
			{
				$('.photo__small >ul>li> img[alt^="2"]').removeClass("opacity");
				return "non-opacity";
			});
			$('.photo__big > img[alt^="2"]').attr("alt","1");
			$('.photo__small >ul>li> img[alt^="2"]').attr("alt","1");
			$('.photo__big > img[alt^="3"]').attr("alt","2");
			$('.photo__small >ul>li> img[alt^="3"]').attr("alt","2");
			$('.photo__big > img[alt^="4"]').attr("alt","3");
			$('.photo__small >ul>li> img[alt^="4"]').attr("alt","3");
			$('.photo__big > img[alt^="10"]').attr("alt","4");
			$('.photo__small >ul>li> img[alt^="10"]').attr("alt","4");
		}
	function func() {
	
	$(".visible__ul").siblings().addClass(function(v_class){

			$(".visible__ul").siblings().removeClass("active-link");
			return "active-link_new";
	});
}
function unfunc() {
	
	$(".visible__ul").siblings().addClass(function(v_class){

			$(".visible__ul").siblings().removeClass("active-link_new");
			return "active-link";
	});
}

window.onscroll = function() {
	var scrol = window.pageYOffset;
		if (scrol > 69)
		{
			$(".nav").addClass(function(v_class){
				$(this).removeClass("nav");
				return "nav_fix";
			});
			// $(".nav_fix").css({"z-index":"5000"})
			$(".header__left").addClass(function(v_class){
				$(this).removeClass("header__left");
				return "header__left_fix";
			});
			$(".header__left_fix > a > img").css({
				"padding-top":"10px",
				"transition":"0.5s",
				"width":"83.25px",
				"height":"40.5px",
				
			});
			// $(".header__left_fix").css({"z-index":"5020"});
			
		}
		
		else{
			$(".nav_fix").addClass(function(v_class){
				$(this).removeClass("nav_fix");
				return "nav";
			});
			$(".header__left_fix").addClass(function(v_class){
				$(this).removeClass("header__left_fix");
				return "header__left";
			});
			$(".header__left > a > img").css({
				"width":"111px",
				"height":"54px"
			});
		}
}